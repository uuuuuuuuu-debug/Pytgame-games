{
 "cells": [
  {
   "cell_type": "code",
   "execution_count": 1,
   "metadata": {},
   "outputs": [
    {
     "name": "stdout",
     "output_type": "stream",
     "text": [
      "pygame 1.9.6\n",
      "Hello from the pygame community. https://www.pygame.org/contribute.html\n"
     ]
    }
   ],
   "source": [
    "import pygame"
   ]
  },
  {
   "cell_type": "code",
   "execution_count": 2,
   "metadata": {},
   "outputs": [],
   "source": [
    "class Map(pygame.sprite.Sprite):\n",
    "    def __init__(self, size, q):\n",
    "        self.cell_x = q[0]\n",
    "        self.cell_y = q[1]\n",
    "        self.map = []\n",
    "        for i in range(size[1] // q[1]):\n",
    "            self.map.append([])\n",
    "            for x in range(size[0] // q[0]):\n",
    "                #self.map[i].append(randint(0, 1))\n",
    "                self.map[i].append(0)\n",
    "    def draw_map(self, size, q, screen):\n",
    "        for i in range(size[1] // q[1]):\n",
    "            for x in range(size[0] // q[0]):\n",
    "                if self.map[i][x] == 1:\n",
    "                    pygame.draw.rect(screen, (100, 56, 179), (x * self.cell_x, i * self.cell_y, self.cell_x, self.cell_y))\n",
    "                    pygame.draw.rect(screen, (0, 0, 0), (x * self.cell_x, i * self.cell_y, self.cell_x, self.cell_y), 1)\n",
    "                if self.map[i][x] == 0:\n",
    "                    pygame.draw.rect(screen, (200, 156, 179), (x * self.cell_x, i * self.cell_y, self.cell_x, self.cell_y))\n",
    "                    pygame.draw.rect(screen, (0, 0, 0), (x * self.cell_x, i * self.cell_y, self.cell_x, self.cell_y), 1)\n",
    "                #for k in range(2, 9):\n",
    "                    #if map[i][x] == k:\n",
    "                        #screen.blit(image[k - 2], (x * self.cell_x, i * self.cell_y))\n",
    "                        #print(\"ya\")\n",
    "                if self.map[i][x] == 2:\n",
    "                    #screen.blit(image[0], (x * self.cell_x, i * self.cell_y))\n",
    "                    pygame.draw.rect(screen, (110, 0, 20), (i * 20, x * 20, 20, 20), 0)\n",
    "                    print(\"1\")\n",
    "                \n",
    "                #if map[i][x] > 1:\n",
    "                    #map[i][x] += 1\n",
    "                #self.map[i][x] = self.map[i][x] % 3\n",
    "        "
   ]
  },
  {
   "cell_type": "code",
   "execution_count": 3,
   "metadata": {},
   "outputs": [],
   "source": [
    "def click(Map, event, size, q):\n",
    "    click = pygame.mouse.get_pressed()[0]\n",
    "    pos = pygame.mouse.get_pos()\n",
    "    if click:\n",
    "        for i in range(size[1] // q[1]):\n",
    "            if pos[1] >= i * Map.cell_y and pos[1] <= (i + 1) * Map.cell_y:\n",
    "                for x in range(size[0] // q[0]):\n",
    "                    if pos[0] >= x * Map.cell_x and pos[0] <= (x + 1) * Map.cell_x:\n",
    "                        Map.map[i][x] = (Map.map[i][x] + 1)%2\n",
    "    return Map"
   ]
  },
  {
   "cell_type": "code",
   "execution_count": null,
   "metadata": {},
   "outputs": [],
   "source": []
  },
  {
   "cell_type": "code",
   "execution_count": 4,
   "metadata": {},
   "outputs": [],
   "source": [
    "def Check(bullets, Map):\n",
    "    for i in range(len(Map.map)):\n",
    "        for x in range(len(Map.map[1])):\n",
    "            for bullet in bullets.sprites():\n",
    "                if bullet.rect.y >= i * Map.cell_y and bullet.rect.y >= (i + 1) * Map.cell_y:\n",
    "                    if bullet.rect.x >= x * Map.cell_x and bullet.rect.x >= (x + 1) * Map.cell_x:\n",
    "                        bullets.remove(bullet)\n",
    "                        Map[i][x] = 2\n",
    "    return (bullets, Map)"
   ]
  },
  {
   "cell_type": "code",
   "execution_count": 5,
   "metadata": {},
   "outputs": [],
   "source": [
    "def draw():\n",
    "    image1 = pygame.image.load('Expload1.png')\n",
    "    image2 = pygame.image.load('Expload2.png')\n",
    "    image3 = pygame.image.load('Expload3.png')\n",
    "    image4 = pygame.image.load('Expload4.png')\n",
    "    image5 = pygame.image.load('Expload5.png')\n",
    "    image6 = pygame.image.load('Expload6.png')\n",
    "    image7 = pygame.image.load('Expload7.png')\n",
    "    image8 = pygame.image.load('Expload8.png')\n",
    "    image = [image1, image2, image3, image4, image5, image6, image7, image8]\n",
    "    import random\n",
    "    from random import randint\n",
    "    clock = pygame.time.Clock()\n",
    "    size = (700, 800)\n",
    "    screen = pygame.display.set_mode(size)\n",
    "    k = True\n",
    "    q = (35, 40)\n",
    "    map1 = Map(size, q)\n",
    "    while k:\n",
    "        clock.tick(10)\n",
    "\n",
    "        for event in pygame.event.get():\n",
    "            if event.type == pygame.QUIT:\n",
    "                k = False\n",
    "            elif event.type == pygame.KEYDOWN:\n",
    "                if event.key == pygame.K_ESCAPE:\n",
    "                    k = False\n",
    "            map1 = click(map1, event, size, q)\n",
    "        map1.draw_map(size, q, screen, image)\n",
    "        pygame.display.flip()\n",
    "        screen.fill(0)\n",
    "    pygame.quit()\n",
    "    return map1"
   ]
  },
  {
   "cell_type": "code",
   "execution_count": 6,
   "metadata": {},
   "outputs": [],
   "source": [
    "pygame.quit()"
   ]
  },
  {
   "cell_type": "code",
   "execution_count": null,
   "metadata": {},
   "outputs": [],
   "source": []
  }
 ],
 "metadata": {
  "anaconda-cloud": {},
  "kernelspec": {
   "display_name": "Python 3",
   "language": "python",
   "name": "python3"
  },
  "language_info": {
   "codemirror_mode": {
    "name": "ipython",
    "version": 3
   },
   "file_extension": ".py",
   "mimetype": "text/x-python",
   "name": "python",
   "nbconvert_exporter": "python",
   "pygments_lexer": "ipython3",
   "version": "3.7.4"
  }
 },
 "nbformat": 4,
 "nbformat_minor": 1
}
